#!/bin/bash
sed "s/passwd=''/passwd='549'/g" monitor/webapi/sql.py > tmp.py
mv tmp.py monitor/webapi/sql.py

sed "s/passwd=''/passwd='549'/g" monitor/report/check_url.py > tmp.py
mv tmp.py monitor/report/check_url.py

sed "s/passwd=''/passwd='549'/g" monitor/report/send_email.py > tmp.py
mv tmp.py monitor/report/send_email.py

sed "s/#send_email/send_email/g" monitor/report/send_email.py > tmp.py
mv tmp.py monitor/report/send_email.py


sed "s/passwd=''/passwd='549'/g" alive/send_email.py > tmp.py
mv tmp.py alive/send_email.py

sed "s/#send_email/send_email/g" alive/send_email.py > tmp.py
mv tmp.py alive/send_email.py


sed "s/WORK_DIR=.*/WORK_DIR=~\/monitor\/monitor\/report\//g" monitor/report/script/start.sh > tmp.sh
mv  tmp.sh monitor/report/script/start.sh
chmod +x monitor/report/script/start.sh


sed "s/WORK_DIR=.*/WORK_DIR=~\/monitor\/monitor\/webapi\//g" monitor/webapi/script/start.sh > tmp.sh
mv  tmp.sh monitor/webapi/script/start.sh
chmod +x monitor/webapi/script/start.sh






