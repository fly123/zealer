import tornado.ioloop
import tornado.web
import logic
import os


CUR_DIR = os.path.split(os.path.realpath(__file__))[0]


settings = {
    'debug' : True,
    "cookie_secret": "61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=",
    "login_url": "/login",
    }


def make_app():
    return tornado.web.Application([
        (r"/", logic.MainHandler),
        (r"/js/(.*)", tornado.web.StaticFileHandler, {"path" : CUR_DIR + "/../web_page/js"}),
        (r"/datejs/(.*)", tornado.web.StaticFileHandler, {"path": CUR_DIR + "/../web_page/datejs"}),
        (r"/highchart/(.*)", tornado.web.StaticFileHandler, {"path": CUR_DIR + "/../web_page/highchart"}),
        (r"/css/(.*)", tornado.web.StaticFileHandler, {"path": CUR_DIR + "/../web_page/css"}),
        (r"/login", logic.LoginHandler),
        (r"/monitor/addUrl", logic.AddUrlHandler),
        (r"/monitor/delUrl", logic.DelUrlHandler),
        (r"/monitor/updateUrl", logic.UpdateUrlHandler),
        (r"/monitor/getUrl", logic.GetUrlHandler),
        (r"/monitor/getUrlList", logic.GetUrlListHandler),
        (r"/monitor/setStatus", logic.SetStatusHandler),
    ], **settings)


if __name__ == "__main__":
    app = make_app()
    app.listen(8888)
    tornado.ioloop.IOLoop.current().start()
