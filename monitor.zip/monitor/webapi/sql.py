# encoding=utf-8
import MySQLdb
import json
import datetime
import time
import math


def init_sql():
    try:
        conn = MySQLdb.connect(host='localhost', user='root', passwd='', db='db_monitor', port=3306, charset='utf8')
        return conn
    except MySQLdb.Error, e:
        print "Mysql Error %d: %s" % (e.args[0], e.args[1])


def string_to_timestamp(time_str):
    time_array = time.strptime(time_str, "%Y-%m-%d %H:%M:%S")
    timestamp = int(time.mktime(time_array))
    return timestamp


def timestamp_to_string(timestamp):
    time_array = time.localtime(timestamp)
    time_str = time.strftime("%Y-%m-%d %H:%M:%S", time_array)
    return time_str


def SqlLoginHandler(userName, passwd):
    result = 0
    try:
        conn = init_sql()
        cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
        sql = 'select * from t_user where user_name = %s and passwd = %s'
        sql_values = (userName, passwd)
        cur.execute(sql, sql_values)
        conn.commit()
        user_results = cur.fetchall()
        if len(user_results) == 0:
            result = 1
        cur.close()
        conn.close()
    except MySQLdb.Error, e:
        print "SqlGetUrlHandler Mysql Error %d: %s" % (e.args[0], e.args[1])
        result = -1

    return result


def SqlAddUrlHandler(url='http://aaa.com', maxTimes='5', description='aaa', method='0'):
    result = 0
    try:
        conn = init_sql()
        cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
        sql = 'insert into t_url (url, maxTimes, description, method) values (%s, %s, %s, %s)'
        sql_values = (url, maxTimes, description, method)
        cur.execute(sql, sql_values)
        conn.commit()
        cur.close()
        conn.close()
    except MySQLdb.Error, e:
        print "SqlAddUrlHandler Mysql Error %d: %s" % (e.args[0], e.args[1])
        result = -1

    return result


def SqlDelUrlHandler(url_id='1'):
    result = 0
    try:
        conn = init_sql()
        cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
        sql = 'delete from t_url where url_id=%s'
        sql_values = tuple([url_id])
        cur.execute(sql, sql_values)
        conn.commit()
        cur.close()
        conn.close()
    except MySQLdb.Error, e:
        print "SqlDelUrlHandler Mysql Error %d: %s" % (e.args[0], e.args[1])
        result = -1

    return result


def SqlUpdateUrlHandler(url_id='1', maxTimes='5', description='aaa', method='0'):
    result = 0
    try:
        conn = init_sql()
        cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
        sql = 'update t_url set maxTimes = %s, description = %s, method = %s, update_time = now() where url_id = %s'
        sql_values = (maxTimes, description, method, url_id)
        cur.execute(sql, sql_values)
        conn.commit()
        cur.close()
        conn.close()
    except MySQLdb.Error, e:
        print "SqlUpdateUrlHandler Mysql Error %d: %s" % (e.args[0], e.args[1])
        result = -1

    return result


def SqlGetUrlHandler(url_id='1', date='2016-01-01'):
    result = 0
    try:
        conn = init_sql()
        cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
        table_name = 't_response_' + date.replace("-", '_')
        sql = 'select u.url, r.* from t_url as u, ' + table_name + ' as r where u.url_id = r.url_id and u.url_id = %s order by r.response_id asc'
        sql_values = tuple([url_id])
        cur.execute(sql, sql_values)
        conn.commit()
        content_results = cur.fetchall()

        if len(content_results) == 0:
            return {}

        response_list = []
        result_dict = {}
        result_dict['date'] = date
        result_dict['url'] = content_results[0]['url']

        time_str = '%s 00:00:00' % date
        time1 = string_to_timestamp(time_str)
        index = 0

        while time1 < (string_to_timestamp(time_str) + 3600 * 24):
            if time1 > string_to_timestamp(str(content_results[-1]['create_time'])):
                break

            sum_time = 0
            count = 0
            '''
            while index < len(content_results):
                content_result = content_results[index]
                time2 = string_to_timestamp(str(content_result['create_time']))
                if time2 >= time1 and (time2 < time1 + 3600):
                    count += 1
                    sum_time += content_result['responseTime']
                    index += 1
                    continue
                break
            '''

            for content_result in content_results:
                time2 = string_to_timestamp(str(content_result['create_time']))
                if time2 >= time1 and (time2 < time1 + 3600):
                    count += 1
                    sum_time += content_result['responseTime']

            response_dict = {}
            response_dict['time'] = timestamp_to_string(time1)[11 : 13]
            response_dict['responseTime'] = 0
            if count > 0:
                response_dict['responseTime'] = sum_time / count
            response_list.append(response_dict)

            time1 += 3600

        result_dict['responseList'] = response_list
        result = result_dict
        cur.close()
        conn.close()
    except MySQLdb.Error, e:
        print "SqlGetUrlHandler Mysql Error %d: %s" % (e.args[0], e.args[1])
        result = -1

    return result


def SqlGetUrlListHandler(page='1', pageSize='10'):
    result = 0
    try:
        conn = init_sql()
        cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
        sql = 'select * from t_url order by url_id desc'
        #sql_values = (int(pageSize), (int(page) - 1) * int(pageSize))
        #cur.execute(sql, sql_values)
        cur.execute(sql)
        conn.commit()
        url_results = cur.fetchall()

        if len(url_results) == 0:
            return []

        totalPageNum = int(math.ceil(len(url_results) / float(pageSize)))
        st_pos = (int(page) - 1) * int(pageSize)
        end_pos = int(page) * int(pageSize)
        if len(url_results) > st_pos:
            url_results = url_results[st_pos : end_pos]
        else:
            return -1
        #print url_results
        url_id_list = []
        for url_result in url_results:
            url_id_list.append(str(url_result['url_id']))

        #print url_id_list

        current_date = datetime.datetime.now().strftime("%Y_%m_%d")
        table_name = 't_response_' + current_date
        response_sql = 'select url_id, count(response_id) as num from ' + table_name + ' where url_id in (' + (', '.join(['%s'] * len(url_id_list))) + ') and responseTime = 0 group by url_id'
        response_sql_values = tuple(url_id_list)
        cur.execute(response_sql, response_sql_values)
        conn.commit()
        response_results = cur.fetchall()

        response_dict = {}
        for response_result in response_results:
            response_dict[response_result['url_id']] = response_result

        result_list = []
        for url_result in url_results:
            result_dict = {}
            result_dict['id'] = url_result['url_id']
            result_dict['url'] = url_result['url']
            result_dict['description'] = url_result['description']
            result_dict['updateTime'] = str(url_result['update_time'])
            result_dict['failTimes'] = 0
            if response_dict.has_key(url_result['url_id']):
                result_dict['failTimes'] = response_dict[url_result['url_id']]['num']
            result_dict['status'] = url_result['status']
            result_dict['method'] = url_result['method']
            result_dict['status'] = url_result['status']

            result_list.append(result_dict)

        result_dict = {}
        result_dict['urlList'] = result_list
        result_dict['totalPageNum'] = totalPageNum
        result = result_dict
        cur.close()
        conn.close()
    except MySQLdb.Error, e:
        print "SqlGetUrlHandler Mysql Error %d: %s" % (e.args[0], e.args[1])
        result = -1

    return result


def SqlSetStatusHandler(url_id='1', status='0'):
    result = 0
    try:
        conn = init_sql()
        cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
        sql = 'update t_url set status = %s where url_id = %s'
        sql_values = (status, url_id)
        cur.execute(sql, sql_values)
        conn.commit()
        cur.close()
        conn.close()
    except MySQLdb.Error, e:
        print "SqlSetStatusHandler Mysql Error %d: %s" % (e.args[0], e.args[1])
        result = -1

    return result


if __name__ == '__main__':
    #product_list = SqlAddUrlHandler()
    SqlDelUrlHandler('10')
    #print product_list
    # result = json.dumps(product_list)#, encoding="utf-8")
    # print result