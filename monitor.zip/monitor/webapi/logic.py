import tornado.ioloop
import tornado.web
import json
import sql
import os

CUR_DIR = os.path.split(os.path.realpath(__file__))[0]


class BaseHandler(tornado.web.RequestHandler):
    def get_current_user(self):
        return self.get_secure_cookie("user")


class MainHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        #print CUR_DIR
        #self.write("Hello, world1234")
        page_file = CUR_DIR + '/../web_page/Monitor.html'
        self.render(page_file)


class LoginHandler(BaseHandler):
    def get(self):
        #print self.current_user
        #if not self.current_user:
        #    self.redirect("/login")
        #    return
        '''
        self.write('<html><body><form action="/login" method="post">'
                   'Name: <input type="text" name="name">'
                   '<input type="submit" value="Sign in">'
                   '</form></body></html>')
        '''
        page_file = CUR_DIR + '/../web_page/Login.html'
        self.render(page_file)


    def post(self):
        result_dict = {}
        result_dict['code'] = '0'
        result_dict['msg'] = 'Success'

        userName = self.get_argument('userName')
        passwd = self.get_argument('passwd')

        code = sql.SqlLoginHandler(userName, passwd)
        if code == 0:
            self.set_secure_cookie("user", self.get_argument("userName"))
            self.set_cookie("userName", self.get_argument("userName"))
            #self.redirect("/")
            #print "sdfsd" * 10
            #self.write()
            #return
        else:
            result_dict['code'] = '-1'
            result_dict['msg'] = 'fail'
        result = json.dumps(result_dict)
        self.write(result)
        #self.set_secure_cookie("user", self.get_argument("name"))
        #self.redirect("/login")


#curl "http://127.0.0.1:8888/addUrl" -d "url=http://aaa.com&maxTimes=5&description=aaa&method=0"
class AddUrlHandler(BaseHandler):
    def post(self):
        result_dict = {}
        result_dict['code'] = '0'
        result_dict['msg'] = 'Success'

        url = self.get_argument('url')
        maxTimes = self.get_argument('maxTimes')
        description = self.get_argument('description')
        method = self.get_argument('method')

        code = sql.SqlAddUrlHandler(url, maxTimes, description, method)
        if code != 0:
            result_dict['code'] = '-1'
            result_dict['msg'] = 'fail'
        result = json.dumps(result_dict)

        self.write(result)


#curl "http://127.0.0.1:8888/delUrl" -d "url_id=1"
class DelUrlHandler(BaseHandler):
    def post(self):
        result_dict = {}
        result_dict['code'] = '0'
        result_dict['msg'] = 'Success'

        url_id = self.get_argument('url_id')

        code = sql.SqlDelUrlHandler(url_id)
        if code != 0:
            result_dict['code'] = '-1'
            result_dict['msg'] = 'fail'
        result = json.dumps(result_dict)

        self.write(result)


#curl "http://127.0.0.1:8888/updateUrl" -d "url_id=5&maxTimes=5&description=bbb&method=0"
class UpdateUrlHandler(BaseHandler):
    def post(self):
        result_dict = {}
        result_dict['code'] = '0'
        result_dict['msg'] = 'Success'

        url_id = self.get_argument('url_id')
        maxTimes = self.get_argument('maxTimes')
        description = self.get_argument('description')
        method = self.get_argument('method')

        code = sql.SqlUpdateUrlHandler(url_id, maxTimes, description, method)
        if code != 0:
            result_dict['code'] = '-1'
            result_dict['msg'] = 'fail'
        result = json.dumps(result_dict)

        self.write(result)


#http://127.0.0.1:8888/getUrl?url_id=5&date=2016-01-01
class GetUrlHandler(BaseHandler):
    def post(self):
        result_dict = {}
        result_dict['code'] = '0'
        result_dict['msg'] = 'Success'

        url_id = self.get_argument('url_id')
        date = self.get_argument('date')

        data = sql.SqlGetUrlHandler(url_id, date)
        result_dict['data'] = data
        result = json.dumps(result_dict)

        self.write(result)


#http://127.0.0.1:8888/getUrlList?page=1&pageSize=2
class GetUrlListHandler(BaseHandler):
    def get(self):
        result_dict = {}
        result_dict['code'] = '0'
        result_dict['msg'] = 'Success'

        page = self.get_argument('page')
        pageSize = self.get_argument('pageSize')

        data = sql.SqlGetUrlListHandler(page, pageSize)
        result_dict['data'] = data
        result = json.dumps(result_dict)

        self.write(result)


#curl "http://127.0.0.1:8888/setStatus" -d "url_id=5&status=1"
class SetStatusHandler(BaseHandler):
    def post(self):
        result_dict = {}
        result_dict['code'] = '0'
        result_dict['msg'] = 'Success'

        url_id = self.get_argument('url_id')
        status = self.get_argument('status')

        code = sql.SqlSetStatusHandler(url_id, status)
        if code != 0:
            result_dict['code'] = '-1'
            result_dict['msg'] = 'fail'
        result = json.dumps(result_dict)

        self.write(result)
