import tornado.ioloop
import tornado.web
import time
import threading
import send_email


ALIVE = False


def check_alive():
    global ALIVE
    while True:
        time.sleep(300)
        if ALIVE == False:
            print "die"
            time_array = time.localtime(time.time())
            time_str = time.strftime("%H", time_array)
            if time_str > '01' and time_str < '08':
                pass
            else:
                send_email.main()

        ALIVE = False



class MainHandler(tornado.web.RequestHandler):
    def get(self):
        global ALIVE
        ALIVE = True
        self.write("Hello, world")


def make_app():
    return tornado.web.Application([
        (r"/", MainHandler),
    ])



if __name__ == "__main__":
    t = threading.Thread(target=check_alive, args=())
    t.start()
    app = make_app()
    app.listen(8889)
    tornado.ioloop.IOLoop.current().start()
