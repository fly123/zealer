# encoding:utf-8
import urllib
import urllib2
import os
import sys
import MySQLdb
import time
import datetime
import smtplib
from email.mime.text import MIMEText
from email.header import Header


USER_NAME = 'hyperionserver@163.com'
PASSWD = 'paic1234'
SERNDER = USER_NAME


def init_sql():
    try:
        conn = MySQLdb.connect(host='localhost', user='root', passwd='', db='db_monitor', port=3306, charset='utf8')
        return conn
    except MySQLdb.Error, e:
        print "Mysql Error %d: %s" % (e.args[0], e.args[1])


def get_receiver_list():
    conn = init_sql()
    cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
    sql = 'select * from t_user'
    cur.execute(sql)
    conn.commit()
    user_list = cur.fetchall()

    receiver_list = []
    for user_dict in user_list:
        receiver_list.append(user_dict['email'])

    return receiver_list


def send_email(body_text, title, receiver_list):
    msg = MIMEText(body_text, 'html', 'utf-8')
    msg['Subject'] = Header(title, 'utf-8')
    msg['To'] = ",".join(receiver_list)

    smtp = smtplib.SMTP()

    smtp.connect('smtp.163.com')
    smtp.ehlo()
    smtp.starttls()
    smtp.ehlo()
    smtp.set_debuglevel(1)

    smtp.login(USER_NAME, PASSWD)
    smtp.sendmail(SERNDER, receiver_list, msg.as_string())
    smtp.quit()


def main():
    receiver_list = get_receiver_list()
    #print receiver_list
    body_text = '内网监控平台挂掉, 在mini机2号'

    if body_text != '':
        print body_text
        #send_email(body_text, '接口挂掉', receiver_list)
        pass


if __name__ == '__main__':
    main()
