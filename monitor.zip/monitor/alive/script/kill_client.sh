#!/bin/bash
ps -ef | grep python | grep "client.py alive" | grep -v grep | awk '{print $2}' | xargs -i kill -9 {}