#!/bin/bash
WORK_DIR=~/monitor/monitor/alive

cd ${WORK_DIR}

TARGET="server.py alive"
result=`ps -ewf|grep "$TARGET"|grep -wv grep|grep -wv vi | grep -wv tail | grep -wv check_alive | grep -v "\.sh" | grep -v "/alarm " |grep -v "vim"| wc -l `
echo $result

#进程不存在，则告警并重启
NOW_TIME=`date +'%Y-%m-%d %H:%M:%S'`
if [ "$result" -ne "1"  ]
then
    echo "start $TARGET $NOW_TIME" >> log/server_down.log
    nohup python $TARGET >> log/server_log.txt 2>&1 &
else
    echo "" #""$TARGET exists $NOW_TIME" >> log/server_down.log
fi

