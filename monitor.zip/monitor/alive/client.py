# encoding:utf-8
import urllib
import urllib2
import os
import sys
import ssl
import MySQLdb
import time
import datetime


# if hasattr(ssl, '_create_unverified_context'):
#     ssl._create_default_https_context = ssl._create_unverified_context


def main():
    url = 'http://kanban.tuqitech.com:8889'
    #url = 'http://10.20.11.225:8888/'

    while True:
        try:
            response = urllib2.urlopen(url, timeout=10)
            #print '%s  ==>>  %s' % (url, response.getcode())
        except Exception, e:
            print 'error_url: %s ==>> %s' % (url, e)
        time.sleep(10)


if __name__ == '__main__':
    main()
