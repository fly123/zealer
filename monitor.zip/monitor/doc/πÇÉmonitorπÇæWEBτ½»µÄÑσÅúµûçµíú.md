
#  monitor接口文档
## 修改记录
(接口文档的第一部分为该文档的修改记录，每一次修改改文档都要做记录，如下所示)

|版本|修改内容简介|修改日期|修改人|
|----|--------|--------|------|
|1|创建|2016-06-07|罗嘉飞|



## 1、添加url

###请求URL
http://ip/monitor/addUrl

###请求方法
post

###请求参数
|名称|类型|说明|必须存在|
|-----|-----|-----|----|
|url|string|监控的url|Y|
|maxTimes|string|最大次数|Y|
|description|string|描述|Y|
|method|string|请求的方法, get为0, post为1|Y|

### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
}
```


##2、删除url

###请求URL
http://ip/monitor/delUrl

###请求方法
post

###请求参数
|名称|类型|说明|必须存在|
|----|----|----|----|
|url_id|string|url id|Y|

### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
}
```

##3、修改url

###请求URL
http://ip/monitor/updateUrl

###请求方法
post

###请求参数
|名称|类型|说明|必须存在|
|-----|-----|-----|----|
|id|string|url id|Y|
|maxTimes|string|最大次数|Y|
|description|string|描述|Y|
|method|string|请求的方法, get为0, post为1|Y|

### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
}
```


##4、查询url

###请求URL
http://ip/monitor/getUrl

###请求方法
get

|名称|类型|说明|必须存在|
|----|----|----|--------|
|url_id|string|url id|Y|
|date|string|日期|Y｜

###返回参数
|名称|类型|说明|必须存在|
|----|----|----|--------|
|code|string|状态码<br>|Y|
|msg|string|状态信息|Y|
|url|string|URL地址<br>|Y|
|date|string|日期<br>|Y|
|time|string|时间<br>|Y|
|responseTime|string|响应时间<br>|Y|

### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
	"data":{
	"url": "http://xxxx.com",
	"date" : "2016-05-01",
	"responseList" :
	[
		{

			"time":"12:30",
			"reponseTime" : 100,                          
		},
     	{...}
   ]
}
```


##5、获取url列表

###请求URL
http://ip/monitor|getUrlList

###请求方法
get

###请求参数
|名称|类型|说明|必须存在|
|----|----|----|----|
|page|string|第几页|Y|
|pageSize|string|每页的数量|Y|

###返回参数
|名称|类型|说明|必须存在|
|----|----|----|--------|
|code|string|状态码<br>|Y|
|msg|string|状态信息<br>|Y|
|url|string|URL地址<br>|Y|
|description|string|描述<br>|Y|
|updateTime|string|更新时间<br>|Y|
|failTimes|string|失败次数<br>|Y|
|status|string|0启动, 1禁用|Y|
|method|string|请求的方法, get为0, post为1|Y|
|totalPageNum|string|总页数<br>|Y|

### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
	"data":{
		"urlList":
		[
		{
     		"url": "http://xxxx.com",
			"description":"xxxx",
			"updateTime" : "2016-05-01",
			"failTimes" : 10,
			"status" : 0,
			"method" : 0
		},
     	{...}],

     	totalPageNum : 10
}
```

##6、启动或禁用url

###请求URL
http://ip/monitor/setStatus

###请求方法
post

###请求参数
|名称|类型|说明|必须存在|
|----|----|----|----|
|id|string|url id|Y|
|status|string|0启动, 1禁用|Y|


### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
}
```


##7、登陆

###请求URL
http://ip/monitor/login

###请求方法
post

###请求参数
|名称|类型|说明|必须存在|
|----|----|----|----|
|userName|string|账号|Y|
|passwd|string|密码|Y|


### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
}
```

