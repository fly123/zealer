
#  fpatch更新接口文档
## 修改记录
(接口文档的第一部分为该文档的修改记录，每一次修改改文档都要做记录，如下所示)

|版本|修改内容简介|修改日期|修改人|
|----|--------|--------|------|
|1|创建|2016-01-04|罗嘉飞|


##通用数据字段和说明

### 各个环境对应的服务器ip地址
开发环境(dev)ip地址:http://10.20.11.225 <br>
测试环境(stg)ip地址：http://ff-app-cms-stg1.paic.com.cn <br>
生产环境(prd)ip地址:http://10.47.160.42 <br>
注：以上环境ip为参考值，实际以开发负责人为准



## 1、上传patch(web调用)

###请求URL
http://ip/fpatch/uploadPatch

###请求方法
post

###请求参数
无

###返回参数

|名称|类型|说明|必须存在|
|-----|-----|-----|----|
|appVerId|string|版本号|Y|
|patchFile|文件|patch文件|Y|


### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
}
```

##2、客户端获取patch信息（客户端调用）

###请求URL
http://ip/fpatch/getPatch

###请求方法
get

###请求参数
|名称|类型|说明|必须存在|
|----|----|----|----|
|appId|string|app Id|Y|
|appVer|string|app version|Y|
|os|string|os(android\|ios)|Y|
|sign|string|签名|Y|

#### 接口请求签名算法说明


```
 _PREFIX_: fmm
 _SUFFIX_: 5b1a2d40f9ca4d080e3b4a2b30bf30a5
 _PARAMS_: key1=value1&key2=value2... //把所有请求参数的key按字母升序顺序拼接
 
 生成_sign_的算法  sign=md5(PREI+PARAMS+SUFFIX)

```

###返回参数
|名称|类型|说明|必须存在|
|----|----|----|--------|
|downloadUrl|string|状态码<br>|Y|
|md5|string|状态信息<br>|Y|
|description|string|补丁描述<br>|Y|
|sign|string|对md5的签名|Y|
|signList|array|签名的列表|N|

### 返回值内容实例
```
{
   "code":"0",
    msg":"Success",
    "data":{
		"patchId" : 1,
		"downloadUrl" : "http://xxx",
		"md5" : "sdfsdfsfd",
		"sign" : "xxcvxcvxc",
		"signList" : [
			{"filename" : "xxx.js", "sign" : "cxvxcvxcv"}
			.......
		]
   }
} 
```

##3、获取patch列表(web调用)

###请求URL
http://ip/fpatch/getPatchList

###请求方法
get

|名称|类型|说明|必须存在|
|----|----|----|--------|
|bankId|string|bank id<br>|Y|
|os|string|操作系统|Y|
|page|string|第几页|Y|
|pageSize|string|每页的数量|Y|

###返回参数
|名称|类型|说明|必须存在|
|----|----|----|--------|
|downloadUrl|string|下载链接<br>|Y|
|patchId|string|补丁的id<br>|Y|
|appVer|string|版本号|Y|

### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
	"data":{
		"patchList":[{
     		"patchId":1,
			"downloadUrl":"http:/xxx",
			"appVer" : "1.1"                           
		},
     	{...}]
}
```
##4、启用或禁用patch(web调用)

###请求URL
http://ip/fpatch/updateStatus

###请求方法
post

|名称|类型|说明|必须存在|
|----|----|----|--------|
|patchId|string|补丁的id<br>|Y|
|status|string|0为禁用  1为启用|Y|

###返回参数
|名称|类型|说明|必须存在|
|----|----|----|--------|
|code|string|状态码<br>|Y|
|msg|string|状态信息|Y|

### 返回值内容实例
```
{
	"code" : "0",
	"msg" : "Success",
}
```


##5、下载patch（WEB调用）

###请求URL
http://ip/fpatch/patchDownload

###请求方法
get

###请求参数
|名称|类型|说明|必须存在|
|----|----|----|----|
|pathchId|int|patch Id|Y|

###返回内容
patch文件

