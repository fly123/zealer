# encoding:utf-8
import urllib
import urllib2
import os
import sys
import MySQLdb
import time
import datetime
import smtplib
from email.mime.text import MIMEText
from email.header import Header


USER_NAME = 'hyperionserver@163.com'
PASSWD = 'paic1234'
SERNDER = USER_NAME


def init_sql():
    try:
        conn = MySQLdb.connect(host='localhost', user='root', passwd='', db='db_monitor', port=3306, charset='utf8')
        return conn
    except MySQLdb.Error, e:
        print "Mysql Error %d: %s" % (e.args[0], e.args[1])


def get_receiver_list():
    conn = init_sql()
    cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
    sql = 'select * from t_user'
    cur.execute(sql)
    conn.commit()
    user_list = cur.fetchall()

    receiver_list = []
    for user_dict in user_list:
        receiver_list.append(user_dict['email'])

    return receiver_list


def send_email(body_text, title, receiver_list):
    msg = MIMEText(body_text, 'html', 'utf-8')
    msg['Subject'] = Header(title, 'utf-8')
    msg['To'] = ",".join(receiver_list)

    smtp = smtplib.SMTP()

    smtp.connect('smtp.163.com')
    smtp.ehlo()
    smtp.starttls()
    smtp.ehlo()
    smtp.set_debuglevel(1)

    smtp.login(USER_NAME, PASSWD)
    smtp.sendmail(SERNDER, receiver_list, msg.as_string())
    smtp.quit()


def get_problem_url_list():
    problem_url_list = []
    try:
        conn = init_sql()
        cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
        current_date = datetime.datetime.now().strftime("%Y_%m_%d")
        table_name = 't_response_' + current_date
        sql = 'select r.*, u.url from ' + table_name + ' as r, t_url as u where r.url_id = u.url_id and r.responseTime = 0 and u.status = 0 and r.create_time > date_sub(now(), interval 10 minute)'
        cur.execute(sql)
        conn.commit()
        url_list = cur.fetchall()
        #print url_list

        url_times_dict = {}
        for url_dict in url_list:
            if url_times_dict.has_key(url_dict['url']) == False:
                url_times_dict[url_dict['url']] = 0
            url_times_dict[url_dict['url']] += 1

        for k, v in url_times_dict.items():
            if v >= 5:
                problem_url_list.append(k)
    except Exception, e:
        print "error get_problem_url_list: %s" % e

    return problem_url_list


def main():
    receiver_list = get_receiver_list()
    #print receiver_list
    problem_url_list = get_problem_url_list()
    #print problem_url_list
    body_text = ''
    for problem_url in problem_url_list:
        body_text += problem_url + '</br>'

    if body_text != '':
        print body_text
        #send_email(body_text, '接口挂掉', receiver_list)
        time.sleep(300)
        pass


if __name__ == '__main__':
    main()
