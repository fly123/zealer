# encoding:utf-8
import check_url
import send_email
import time


def main():
    while True:
        check_url.main()
        time_array = time.localtime(time.time())
        time_str = time.strftime("%H", time_array)
        if time_str > '01' and time_str < '08':
            pass
        else:
            send_email.main()
        time.sleep(60)


if __name__ == '__main__':
    main()
