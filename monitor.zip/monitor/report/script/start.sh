#!/bin/bash
WORK_DIR=/data/jiafei/topic/server/webapi/

cd ${WORK_DIR}

TARGET="report.py"
result=`ps -ewf|grep "$TARGET"|grep -wv grep|grep -wv vi | grep -wv tail | grep -wv check_alive | grep -v "\.sh" | grep -v "/alarm " |grep -v "vim"| wc -l `
echo $result

#进程不存在，则告警并重启
NOW_TIME=`date +'%Y-%m-%d %H:%M:%S'`
if [ "$result" -ne "1"  ]
then
    echo "start $TARGET $NOW_TIME" >> log/down.log
    nohup python $TARGET >> log/log.txt 2>&1 &
else
    echo "" #"$TARGET exists $NOW_TIME" >> log/down.log
fi

