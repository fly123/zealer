#!/bin/bash
ps -ef | grep python | grep report.py | grep -v grep | awk '{print $2}' | xargs -i kill -9 {}