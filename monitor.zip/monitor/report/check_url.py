# encoding:utf-8
import urllib
import urllib2
import os
import sys
import ssl
import MySQLdb
import time
import datetime


if hasattr(ssl, '_create_unverified_context'):
    ssl._create_default_https_context = ssl._create_unverified_context


def init_sql():
    try:
        conn = MySQLdb.connect(host='localhost', user='root', passwd='', db='db_monitor', port=3306, charset='utf8')
        return conn
    except MySQLdb.Error, e:
        print "Mysql Error %d: %s" % (e.args[0], e.args[1])


def get_url_list():
    conn = init_sql()
    cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
    sql = 'select * from t_url where status = 0'
    cur.execute(sql)
    conn.commit()
    url_list = cur.fetchall()
    cur.close()
    conn.close()

    return url_list


def sava_reponse(url_id, responseTime):
    conn = init_sql()
    cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)

    current_date = datetime.datetime.now().strftime("%Y_%m_%d")
    table_name = 't_response_' + current_date
    sql = '''use  db_monitor;CREATE TABLE IF not EXISTS `%s` (
      `response_id` int unsigned  NOT NULL auto_increment,
      `url_id` int unsigned NOT NULL default 0 COMMENT 'url id',
      `responseTime` int unsigned NOT NULL default 0 COMMENT '响应时间,毫秒',
      `status` int unsigned NOT NULL default 0 COMMENT '0未检查, 1已检查',
      `create_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT '创建时间',
      `update_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT '更新时间',
       PRIMARY KEY  (`response_id`)
       ) ENGINE=innodb  DEFAULT CHARSET=utf8 COMMENT '响应时间表';''' % table_name
    cur.execute(sql)
    #conn.commit()
    cur.close()

    cur = conn.cursor(cursorclass=MySQLdb.cursors.DictCursor)
    sql = 'insert into ' + table_name + ' (url_id, responseTime) values (%s, %s)'
    sql_values = (url_id, responseTime)
    cur.execute(sql, sql_values)
    conn.commit()

    cur.close()
    conn.close()


def main():
    #print get_url_list()
    for url_dict in get_url_list():
        url = url_dict['url']
        responseTime = 0
        try:
            t1 = time.time()
            response = urllib2.urlopen(url, timeout=10)
            t2 = time.time()
            responseTime = int((t2 - t1) * 1000)
            print '%s  ==>>  %s, responseTime ==>> %s' % (url, response.getcode(), responseTime)
        except:
            print 'error_url: %s' % url

        sava_reponse(url_dict['url_id'], responseTime)


if __name__ == '__main__':
    main()
