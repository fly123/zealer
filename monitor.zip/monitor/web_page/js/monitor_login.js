function login() {

	var accountName = $("#username").val();
	var password = $("#password").val();
	// var jsonData = "accountName":"++accountName+,"+"password:"++password;

	if (accountName.replace(/(^\s*)|(\s*$)/g, "").length == 0) {
		alert('用户名不能为空');
		return false;
	}

	if (password.replace(/(^\s*)|(\s*$)/g, "").length == 0) {
		alert('密码不能为空');
		return false;
	}

//	if ($("#remmbername").is(":checked")) {
//		deleteCookie("accountName");
//		setCookie("accountName", accountName, 30);
//
//	} else {
//		deleteCookie("accountName");
//	}

	var requestUrl = "/login";

	$.ajax({
		type : "post",
		url : requestUrl,
		data : {
			userName : accountName,
			passwd : password
		},
		datatype : "json",
		crossDomain : true,
		success : function loginCallback(data) {
			
			var responseObj = $.evalJSON(data);

			if (responseObj.code == 0) {
				window.location.href =  "/";
			} else {
				alert(responseObj.msg);
			}

		}
	});

	return false;
};

function setCookie(name, value, expireDays) {

	var exdate = new Date();

	exdate.setDate(exdate.getDate() + expireDays);

	var cookieData = name + "=" + escape(value)
			+ ((expireDays == null) ? "" : "; expires=" + exdate.toGMTString());
	document.cookie = cookieData;

}

function getCookie(name) {

	if (document.cookie.length > 0) {

		start = document.cookie.indexOf(name + "=");

		if (start != -1) {
			start = start + name.length + 1;
			end = document.cookie.indexOf(";", start);
			if (end == -1)
				end = document.cookie.length;
			return unescape(document.cookie.substring(start, end));
		}
	}
}

function deleteCookie(name) {

	var exdate = new Date();
	exdate.setTime(exdate.getTime() - 1);
	var value = getCookie(name);
	var cookieData = name + "=" + escape(value) + "; expires="
			+ exdate.toGMTString();
	document.cookie = cookieData;
	console.log("---cookie:" + document.cookie);
}

$(document).ready(function() {

	$("#submitBtn").click(login);

	var accountName = getCookie("accountName");
	if (accountName != null && accountName != "") {
		$("#username").val(accountName);
	}
	;
});
