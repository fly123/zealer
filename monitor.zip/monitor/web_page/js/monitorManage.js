

var statuslist=new Array;

//---分页------------
var Page = React.createClass({

    getInitialState: function() {
        return {
            current: 1,
            value : '',
            total:0
        };
    },
    handClick : function(e){
        let sel = this;
        return function(){
            sel.setState({current : e});
            PubSub.publish(GO_PAGE_STATUS);
        }
    },
    handChange : function(e){
        this.setState({value : e.target.value})
        PubSub.publish(GO_PAGE_CHANGE);
    },
    goNext : function(){

        let cur = this.state.current;
        if(cur < this.state.total){
            this.setState({current : cur + 1});
        }
        PubSub.publish(GO_PAGE_NEXT);
    },
    goPrev : function(){
        let cur = this.state.current;
        if(cur > 1){
            this.setState({current : cur - 1});
        }
        PubSub.publish(GO_PAGE_PREV);
    },
    goPage : function(){
        var val = this.state.value;
        if(!/^[1-9]\d*$/.test(val)){
            alert('页码只能输入大于1的正整数');
        }else if(parseInt(val) > parseInt(this.props.total)){
            alert('没有这么多页');
        }else{
            this.setState({current : val});

        }
        PubSub.publish(GO_PAGE);
    },
    updatePage:function(){
        $.ajax({
                    url: "/monitor/getUrlList",
                    dataType: 'json',
                    data : {
                        page:this.state.current,
                        pageSize:10
                        },
                    cache: false,
                    success: function(response) {

                        if(response.code == "0"){

                            this.setState({total:response.data.totalPageNum});
                            PubSub.publish(MONITOR_PAGE);
                            $('#addMonitorModal').data('urlList',response.data.urlList);
                        }else{
                            handleErrorCode(response);
                        }
                    }.bind(this)
           });
    },
    componentWillMount:function(){
        this.updatePage();

    },
    componentDidMount:function(){

        PubSub.subscribe(GO_PAGE_CHANGE,this.updatePage);
        PubSub.subscribe(GO_PAGE_NEXT,this.updatePage);
        PubSub.subscribe(GO_PAGE_PREV,this.updatePage);
        PubSub.subscribe(GO_PAGE,this.updatePage);
        PubSub.subscribe(GO_PAGE_STATUS,this.updatePage);

        PubSub.subscribe(MONITOR_SET_STATUS,this.updatePage);
		PubSub.subscribe(MONITOR_UPDATE_URL,this.updatePage);
		PubSub.subscribe(MONITOR_ADD_URL,this.updatePage);
		PubSub.subscribe(MONITOR_MODIFY_URL,this.updatePage);
    },
    render : function(){
        let self = this;
        let total = this.state.total;
        let cur = this.state.current;
        let items = [];
        let begin;
        let len;
        if(total > 5){
            len = 5;
            if(cur >= (total-2)){
                begin = total - 4;
            }else if(cur <= 3){
                begin = 1;
            }else{
                begin = cur - 2;
            }
        }else{
            len = total;
            begin = 1;
        }
        for(let i = 0; i < len; i ++){
            let cur = this.state.current;
            let showI = begin + i;
            if(cur == showI){
                items.push({num : showI, cur : true});
            }else{
                items.push({num : showI, cur : false});
            }

        }
        return  <div className="ui-pagnation">
                    <a className={this.state.current == 1? 'prev disable' : 'prev'} onClick={this.goPrev}></a>
                    <span className="pagnation-cols">
                        {
                            items.map(function(item){
                                return <a onClick={self.handClick(item.num)} key={item.num} className={item.cur? 'num current' : 'num'}>{item.num}</a>
                            })
                        }
                    </span>
                    <a className={this.state.current == this.state.total? 'next disable' : 'next'} onClick={this.goNext}></a>
                    <div className="fl">共
                        <span className="num-total">{total}</span>页，到第
                        <input type="text" value={self.state.value} onChange={this.handChange} />
                        页
                    </div>
                    <a onClick={this.goPage} className="page-go">确定</a>
                </div>
    }
});

ReactDOM.render(
    <div>
        <Page />
    </div>,
    document.getElementById('pagination')
);

//---列表-------
var MonitorTableRowInfo = React.createClass({

	clickMonitorLookBtnHandler : function(){

		$('#lookMonitorModal').data('url_id',this.props.monitorInfo.id);
		$('#lookMonitorModal').modal('toggle');

		this.loadDate(this.props.monitorInfo.id);

	},
	loadDate: function(url_id){
	    var birthdays=$("#birthday").val();
	    $('#birthday').daterangepicker(
	        {
                singleDatePicker : true,
                startDate:"2016-06-01",
                maxDate:"3016-06-01",
                endDate:moment()
			},
            function(start, end, label) {
			    $('#birthday input').val(start.toString('yyyy-MM-dd') + '~' + end.toString('yyyy-MM-dd'));
			    getChart(url_id);

            }
        );
	},
	clickModifyMonitorBtnHandler : function(){

		document.getElementById("hiddId").value = this.props.monitorInfo.id;
		document.getElementById("updateAddr").value = this.props.monitorInfo.url;
		document.getElementById("updateMethod").value = (this.props.monitorInfo.method==0? "get":"post");
		document.getElementById("updateDescription").value =this.props.monitorInfo.description;

		$('#modifyMonitorModal').modal('toggle');
	},
	clickDeleteBtnHandler : function(){
		var confirmMessage = "确定删除该监控？";
		
		if(confirm(confirmMessage)){
		    $.ajax({
		    	url: "/monitor/delUrl",
		    	data:{
		    	    url_id:this.props.monitorInfo.id
		    	},
		    	dataType: 'json',
		    	type:'POST',
		    	cache: false,
				success: function(response) {
					if(response.code == 0){
						PubSub.publish(MONITOR_UPDATE_URL);
					}else{
						handleErrorCode(response);
					}
				}.bind(this)
		    }); 
		}
	},
	clickEnableBtnHandler : function(){
		var confirmMessage = "确定禁用监控？";
		var stats = this.props.monitorInfo.status;
        if(stats==1){
                confirmMessage = "确启用监控?";
		        stats = 0;
		    }
		else if(stats==0){
		       stats=1;
		    }
		else{
		        stats = 0;
		}
		if(confirm(confirmMessage)){


		    $.ajax({
		    	url: "/monitor/setStatus",
		    	data:{
		    		url_id : this.props.monitorInfo.id,
		    		status : stats
		    		},
		    	dataType: 'json',
		    	type:'POST',
		    	cache: false,
				success: function(response) {
					if(response.code == 0){
						PubSub.publish(MONITOR_SET_STATUS);
					}else{
						handleErrorCode(response);
					}
				}.bind(this)
		    });
		}
	},
	getInitialState: function() {
	    return {
	    	setStatusUrl : ""
	    };
	},
	componentWillMount:function(){
	    var initdate="";
        var theDate=new Date();
        initdate += theDate.getFullYear()+"-";                         // 获取年份。
        initdate += appendZero(theDate.getMonth() + 1) + "-";            // 获取月份。
        initdate += appendZero(theDate.getDate());                   // 获取日
        document.getElementById("birthday").value = initdate;

	},
	render : function(){

	        var isStatus = this.props.monitorInfo.status == 0? "禁用" : "启用";
            var isUsed = this.props.monitorInfo.status == 0 ? "监控中" : "停用";
            var method = this.props.monitorInfo.method == 0 ? "get" : "post";
				return (
						<tr>
							<td>{this.props.monitorInfo.id}</td>
							<td className={'tb-wordwidth'}>{this.props.monitorInfo.url}</td>
							<td className={'tb-wordwidth'}>{this.props.monitorInfo.description}</td>
							<td>{method}</td>
							<td>{this.props.monitorInfo.failTimes}</td>
									<td>{isUsed}</td>
							<td>
								<button type="button" className="btn btn-success  btn-xs" onClick={this.clickMonitorLookBtnHandler} >查看</button>
								<button type="button" className="btn btn-primary btn-xs marginleft" onClick={this.clickEnableBtnHandler} >{isStatus}</button>
								<button type="button" className="btn btn-info btn-xs marginleft" onClick={this.clickModifyMonitorBtnHandler}>修改</button>
								<button type="button" className="btn btn-danger btn-xs marginleft" onClick={this.clickDeleteBtnHandler}>删除</button>
							</td>
							<td>{this.props.monitorInfo.updateTime}</td>
						</tr>
					);

		}
});
var MonitorTableTbody = React.createClass({
	
	getInitialState: function(){
		return {
			setStatusUrl: "/monitor/getUrlList",
			urlList:[]
		};
	},
	getDataListFromServer:function(){
         var list  = $('#addMonitorModal').data('urlList');
         this.setState({urlList: list});
	},
	componentDidMount:function(){
		this.getDataListFromServer();
		PubSub.subscribe(MONITOR_PAGE,this.getDataListFromServer);

	},
	render : function(){

	        if(this.state.urlList!=null){

		        var rows = this.state.urlList.map( function (monitorInfo){
			        return (
					    <MonitorTableRowInfo monitorInfo={monitorInfo} key={monitorInfo.id} />
					);
				});
				return (<tbody>{rows}</tbody>);
            }
            return (<tbody></tbody>);
	}
});


var MonitorTableArea = React.createClass({
	render : function(){
		
		return (
			<table className="table">
				<thead>
					<tr>
						<th>ID</th>
						<th>地址信息</th>
						<th>描述</th>
						<th>请求方式</th>
						<th>失败总数</th>
						<th>状态</th>
						<th>配置操作</th>
						<th>更新时间</th>
					</tr>
				</thead>
				<MonitorTableTbody/>
			</table>
		);
	}
});

ReactDOM.render(
		<MonitorTableArea />,
		document.getElementById("table_area")
);

//------添加---------
$("#addsubumit").click(function(){

	 var addr = $("#addressInput").val();
	 var maxtimes = $("#monMaxNum").val();
	 var method = $("#askInput").val();
	 var description = $("#urldescription").val();
	 var methodStatus = 1;
	 if(method== "post"){
	    methodStatus =  1;
	 }else{
	    methodStatus = 0;
	 }

	$.ajax({
    	url: "/monitor/addUrl",
    	dataType: 'json',
    	data : {
            url:addr,
            maxTimes:5,
            description:description,
            method:methodStatus
    		},
    	type:'POST',
    	cache: false,
		success: function(response) {

			if(response.code == "0"){

				PubSub.publish(MONITOR_ADD_URL);
			}else{
				handleErrorCode(response);
			}
		}
	})

})
$("#saveUpdateMonitor").click(function(){
	 var hhid = $("#hiddId").val();
	 var updMothed=$("#updateMethod").val();
	 var updateMaxTime=$("#updateMaxTime").val();
	 var updateDescription=$("#updateDescription").val();
     var methodStatus = 1;
	 if($("#updateMethod").val()== "post"){
	    methodStatus =  1;
	 }else{
	    methodStatus = 0;
	 }

	$.ajax({
    	url: "monitor/updateUrl",
    	dataType: 'json',
    	data : {

    		maxTimes:5,
    		description:updateDescription,
    		method:methodStatus,
    		url_id:hhid
    		},
    	type:'POST',
    	cache: false,
		success: function(response) {
			if(response.code == "0"){

				PubSub.publish(MONITOR_MODIFY_URL);
			}else{
				handleErrorCode(response);
			}
			return false;
		}

	})
})
//---图表------
function getChart(url_id){

        var birthdays=$("#birthday").val();
	    var charts = new Highcharts.Chart(
			    {
			        chart: {
								renderTo : 'container',
								defaultSeriesType : 'line', //图表类别，可取值有：line、spline、area、areaspline、bar、column等
								marginRight : 40,
								marginBottom : 45,
								marginTop : 60,
								width :710,
								events:{
										load:getData
										}
							    },
					title : {
								enbled : false,
								text : null, //设置一级标题
								x : 20,
								y : 375
								//center
								},
					subtitle : {
								text : '响应时间曲线图(小时)', //设置二级标题
								//x : -20
								x : 20,
								y : 385
								},
					xAxis :     {

					            categories:[]
                                //设置x轴的标题
								},
					yAxis : {
								title : {
										text : '响应时间(毫秒)' //设置y轴的标题
											},
						        plotLines : [ {
												value : 0,
												width : 1,
												color : '#808080'
											} ]
								},
					path : {
								enable : 0
								},
					tooltip : {
								formatter : function() {
												return '<b>' + this.series.name
														+ '</b><br/>' + this.x
														+ ': ' + this.y + 'm/s'; //鼠标放在数据点的显示信息，但是当设置显示了每个节点的数据项的值时就不会再有这个显示信息
											}
								},
					legend : {
								layout : 'vertical',
								align : 'right', //设置说明文字的文字 left/right/top/
								verticalAlign : 'top',
								x : 0,
								y : 0,
								borderWidth : 0
								},
					exporting : {
								enabled : false, //用来设置是否显示‘打印’,'导出'等功能按钮，不设置时默认为显示
								url : "http://localhost:49394/highcharts_export.aspx" //导出图片的URL，默认导出是需要连到官方网站去的哦
								},
					plotOptions : {
									line : {
										dataLabels : {
										lineColor : '#666666',
										enabled : true
												//显示每条曲线每个节点的数据项的值
											},
												enableMouseTracking : false
											}
									},
					credits : {
								enabled : 0
								},
					series : [
								{
								name : '平均值', //每条线的名称
												//每条线的数据
								}
							]

				});
	    function getData() {
							var datep = $('#birthday').val();
						    var categories = [];

								   $.ajax({
								      type: "post",
								      url: "/monitor/getUrl",
								      data:{
								    	  date:datep,
								    	  url_id:url_id
								      },
								      type:'post',
								      dataType: "json",
								      success : function(response){
								      if(response.code==0){
                                          var x=[];
								    	  var y = [];
								    	  var key;

								    	  for(key in response.data.responseList){
								    		  x.push(response.data.responseList[key].time);
								    		  y.push(response.data.responseList[key].responseTime);
								    	  }

									     charts.series[0].setData(y);
									     charts.xAxis[0].setCategories(x);
								      }else{
								        handleErrorCode(response);
								        }
								      }
								     });
							}

}

$("#lookMonitorModal").on('show.bs.modal',function(){
        var initdate="";
        var theDate=new Date();
        initdate += theDate.getFullYear()+"-";                         // 获取年份。
        initdate += appendZero(theDate.getMonth() + 1) + "-";            // 获取月份。
        initdate += appendZero(theDate.getDate());                   // 获取日
        document.getElementById("birthday").value = initdate;
    var url_id = $('#lookMonitorModal').data('url_id');

    getChart(url_id);
})
function appendZero(s){return ("00"+ s).substr((s+"").length);}