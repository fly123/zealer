/**
 * 
 */
var MONITOR_SET_STATUS="monitor set status";
var MONITOR_UPDATE_URL = "monitor update url";
var MONITOR_ADD_URL ="add config url";

var MONITOR_MODIFY_URL ="modify config url";

var MONITOR_UPDATE_CHART="update chart";
var MONITOR_PAGE="monitor page";

var GO_PAGE = "go page";
var GO_PAGE_PREV = "go page prev";
var GO_PAGE_NEXT = "go page next";
var GO_PAGE_CHANGE = "go page change";
var GO_PAGE_STATUS = "go page state";

