var host = 'http://'+window.location.host;

$.ajaxSetup({
	error : function(request,msg,exception){
		alert("请求失败，请检查网络连接状态");
	}
});


function loginout () {

  window.location.href="/login";
 }

function handleErrorCode (responseObj) {

  if(responseObj.code==7){
      window.location.href = "/login";
  }else{
     alert(responseObj.msg);
  }
}

function trim (str) {

  if(str!=undefined){
    return str.replace(/(^\s*)|(\s*$)/g, "");
  }else{
    return str;
  }
}


function isEmpty(str) {
   if (str == undefined || str == null || str == '') {
     return true;
   }else {
     return false;
   }
}
function getCookie(name) {

	if (document.cookie.length > 0) {

		start = document.cookie.indexOf(name + "=");
		if (start != -1) {
			start = start + name.length + 1;
			end = document.cookie.indexOf(";", start);
			if (end == -1)
				end = document.cookie.length;
			return unescape(document.cookie.substring(start, end));
		}
	}
}


$(document).ready(function(){
    var userName = getCookie("userName");
    $(".login-name").html(userName);
});