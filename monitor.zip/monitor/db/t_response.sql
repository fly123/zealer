CREATE DATABASE  IF not EXISTS db_monitor default character set utf8;
--
--
use  db_monitor; DROP TABLE IF EXISTS `t_response`; CREATE TABLE IF not EXISTS `t_response` (
  `response_id` int unsigned  NOT NULL auto_increment,
  `url_id` int unsigned NOT NULL default 0 COMMENT 'url id',
  `responseTime` int unsigned NOT NULL default 0 COMMENT '响应时间,毫秒',
  `status` int unsigned NOT NULL default 0 COMMENT '0未检查, 1已检查',
  `create_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT '更新时间',
   PRIMARY KEY  (`response_id`)
   ) ENGINE=innodb  DEFAULT CHARSET=utf8 COMMENT '响应时间表';

