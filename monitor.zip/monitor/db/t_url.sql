CREATE DATABASE  IF not EXISTS db_monitor default character set utf8;
--
--
use  db_monitor; DROP TABLE IF EXISTS `t_url`; CREATE TABLE IF not EXISTS `t_url` (
  `url_id` int unsigned  NOT NULL auto_increment,
  `url` char(255) NOT NULL default '' COMMENT '监控的url',
  `description` char(255) NOT NULL default '' COMMENT '描述',
  `maxTimes` int unsigned NOT NULL default 0 COMMENT '最大次数',
  `method` int unsigned NOT NULL default 0 COMMENT '请求方法,get:0, post:1',
  `status` int unsigned NOT NULL default 0 COMMENT '0启动, 1禁用',
  `create_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT '更新时间',
   PRIMARY KEY  (`url_id`),
   unique key `url` (`url`)
) ENGINE=innodb  DEFAULT CHARSET=utf8 COMMENT 'url表';

