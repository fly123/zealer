source /Users/luojiafei419/monitor/db/t_response.sql;

insert into t_response (url_id, responseTime) values (1, 400);
insert into t_response (url_id, responseTime) values (1, 400);
insert into t_response (url_id, responseTime) values (1, 400);
insert into t_response (url_id, responseTime) values (1, 400);
insert into t_response (url_id, responseTime) values (1, 400);
insert into t_response (url_id, responseTime) values (1, 400);