source /Users/luojiafei419/monitor/db/t_url.sql;

insert into t_response (url_id, responseTime) values (1, 400);