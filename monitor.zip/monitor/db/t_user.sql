CREATE DATABASE  IF not EXISTS db_monitor default character set utf8;
--
--
use  db_monitor; DROP TABLE IF EXISTS `t_user`; CREATE TABLE IF not EXISTS `t_user` (
  `user_id` int unsigned  NOT NULL auto_increment,
  `user_name` char(255) NOT NULL default '' COMMENT '用户名',
  `passwd` char(255) NOT NULL default '' COMMENT '密码',
  `email` char(255) NOT NULL default '' COMMENT '邮箱',
  `status` int unsigned NOT NULL default 0 COMMENT '0启动, 1禁用',
  `create_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT '更新时间',
   PRIMARY KEY  (`user_id`),
   unique key `email` (`email`)
) ENGINE=innodb  DEFAULT CHARSET=utf8 COMMENT '用户表';

