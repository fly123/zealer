source /Users/luojiafei419/monitor/db/t_user.sql;
insert into t_user (user_name, passwd, email) values ('luojiafei', 'luojiafei', 'luojiafei419@pingan.com.cn');
insert into t_user (user_name, passwd, email) values ('heliuxing', 'heliuxing', 'heliuxing902@pingan.com.cn');
insert into t_user (user_name, passwd, email) values ('tiancong', 'tiancong', 'tiancong771@pingan.com.cn');
insert into t_user (user_name, passwd, email) values ('huangweigan', 'huangweigan', 'huangweigan007@pingan.com.cn');
insert into t_user (user_name, passwd, email) values ('wuqiongke', 'wuqiongke', 'wuqiongke703@pingan.com.cn');
insert into t_user (user_name, passwd, email) values ('lichuang', 'lichuang', 'lichuang745@pingan.com.cn');
insert into t_user (user_name, passwd, email) values ('yanyueqiang', 'yanyueqiang', 'yanyueqiang484@pingan.com.cn');
insert into t_user (user_name, passwd, email) values ('chenweixin', 'chenweixin', 'chenweixin769@pingan.com.cn');